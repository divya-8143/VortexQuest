@echo off
set "PATH=%~dp0mingit\cmd;%~dp0mingit\cmd\git.exe;%PATH%"
C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe %*
